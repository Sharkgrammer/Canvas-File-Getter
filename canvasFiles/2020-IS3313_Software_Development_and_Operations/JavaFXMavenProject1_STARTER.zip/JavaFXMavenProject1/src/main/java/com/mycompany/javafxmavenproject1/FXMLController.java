package com.mycompany.javafxmavenproject1;

import java.io.IOException;
import java.net.URL;
import java.util.ResourceBundle;
import java.util.logging.Level;
import java.util.logging.Logger;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.Initializable;
import javafx.scene.control.Label;

public class FXMLController implements Initializable {
    
    @FXML
    private Label label;
    
    @FXML
    private void handleButtonAction(ActionEvent event) {
        label.setText("Fetching data");
        String responseData = LocationEntryDAO.fetchLocation(1).toString();
        System.out.println("You clicked me! " + responseData);
        label.setText(responseData);
    }
    
    @Override
    public void initialize(URL url, ResourceBundle rb) {
        // TODO
    }
 
}
