package com.mycompany.javafxmavenproject1;

import java.io.IOException;
import java.net.URL;
import java.util.ResourceBundle;
import java.util.logging.Level;
import java.util.logging.Logger;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.Initializable;
import javafx.scene.control.Label;
import okhttp3.Call;
import okhttp3.OkHttpClient;
import okhttp3.Request;
import okhttp3.Response;

public class FXMLController implements Initializable {
    
    private static final String BASE_URI = "https://location.simonwoodworth.com/gateway.php/location/";
    private OkHttpClient client = new OkHttpClient();
    
    @FXML
    private Label label;
    
    @FXML
    private void handleButtonAction(ActionEvent event) {
        label.setText("Fetching data");
        String responseData = fetchData(1);
        System.out.println("You clicked me! " + responseData);
        label.setText(responseData);
    }
    
    @Override
    public void initialize(URL url, ResourceBundle rb) {
        // TODO
    }

    private String fetchData(int id) {
                
        Request request = new Request.Builder()
            .url(BASE_URI + id)
            .build();
 
        Call call = client.newCall(request);
        try {
            Response response = call.execute();
            return response.body().string();
        } catch (IOException ex) {
            Logger.getLogger(FXMLController.class.getName()).log(Level.SEVERE, null, ex);
            return "FAIL";
        }
    }
 
}
