/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.mycompany.javafxmavenproject1;

import org.junit.After;
import org.junit.AfterClass;
import org.junit.Before;
import org.junit.BeforeClass;
import org.junit.Test;
import static org.junit.Assert.*;

/**
 *
 * @author simon
 */
public class LocationEntryTest {
    
    public LocationEntryTest() {
    }
    
    @BeforeClass
    public static void setUpClass() {
    }
    
    @AfterClass
    public static void tearDownClass() {
    }
    
    @Before
    public void setUp() {
    }
    
    @After
    public void tearDown() {
    }

    /**
     * Test of getId method, of class LocationEntry.
     */
    @Test
    public void testGetId() {
        System.out.println("getId");
        LocationEntry instance = new LocationEntry(55,5.5,6.6,"NOW","TEST");
        long expResult = 55L;
        long result = instance.getId();
        assertEquals(expResult, result);
    }

    /**
     * Test of setId method, of class LocationEntry.
     */
    @Test
    public void testSetId() {
        System.out.println("setId");
        long ID = 0L;
        LocationEntry instance = new LocationEntry();
        instance.setId(ID);
        // TODO review the generated test code and remove the default call to fail.
        fail("The test case is a prototype.");
    }

    /**
     * Test of getLat method, of class LocationEntry.
     */
    @Test
    public void testGetLat() {
        System.out.println("getLat");
        LocationEntry instance = new LocationEntry();
        double expResult = 0.0;
        double result = instance.getLat();
        assertEquals(expResult, result, 0.0);
        // TODO review the generated test code and remove the default call to fail.
        fail("The test case is a prototype.");
    }

    /**
     * Test of setLat method, of class LocationEntry.
     */
    @Test
    public void testSetLat() {
        System.out.println("setLat");
        double Lat = 0.0;
        LocationEntry instance = new LocationEntry();
        instance.setLat(Lat);
        // TODO review the generated test code and remove the default call to fail.
        fail("The test case is a prototype.");
    }

    /**
     * Test of getLng method, of class LocationEntry.
     */
    @Test
    public void testGetLng() {
        System.out.println("getLng");
        LocationEntry instance = new LocationEntry();
        double expResult = 0.0;
        double result = instance.getLng();
        assertEquals(expResult, result, 0.0);
        // TODO review the generated test code and remove the default call to fail.
        fail("The test case is a prototype.");
    }

    /**
     * Test of setLng method, of class LocationEntry.
     */
    @Test
    public void testSetLng() {
        System.out.println("setLng");
        double Lng = 0.0;
        LocationEntry instance = new LocationEntry();
        instance.setLng(Lng);
        // TODO review the generated test code and remove the default call to fail.
        fail("The test case is a prototype.");
    }

    /**
     * Test of getDatetime method, of class LocationEntry.
     */
    @Test
    public void testGetDatetime() {
        System.out.println("getDatetime");
        LocationEntry instance = new LocationEntry();
        String expResult = "";
        String result = instance.getDatetime();
        assertEquals(expResult, result);
        // TODO review the generated test code and remove the default call to fail.
        fail("The test case is a prototype.");
    }

    /**
     * Test of setDatetime method, of class LocationEntry.
     */
    @Test
    public void testSetDatetime() {
        System.out.println("setDatetime");
        String Time = "";
        LocationEntry instance = new LocationEntry();
        instance.setDatetime(Time);
        // TODO review the generated test code and remove the default call to fail.
        fail("The test case is a prototype.");
    }

    /**
     * Test of getNote method, of class LocationEntry.
     */
    @Test
    public void testGetNote() {
        System.out.println("getNote");
        LocationEntry instance = new LocationEntry();
        String expResult = "";
        String result = instance.getNote();
        assertEquals(expResult, result);
        // TODO review the generated test code and remove the default call to fail.
        fail("The test case is a prototype.");
    }

    /**
     * Test of setNote method, of class LocationEntry.
     */
    @Test
    public void testSetNote() {
        System.out.println("setNote");
        String Note = "";
        LocationEntry instance = new LocationEntry();
        instance.setNote(Note);
        // TODO review the generated test code and remove the default call to fail.
        fail("The test case is a prototype.");
    }

    /**
     * Test of toString method, of class LocationEntry.
     */
    @Test
    public void testToString() {
        System.out.println("toString");
        LocationEntry instance = new LocationEntry();
        String expResult = "";
        String result = instance.toString();
        assertEquals(expResult, result);
        // TODO review the generated test code and remove the default call to fail.
        fail("The test case is a prototype.");
    }
    
}
