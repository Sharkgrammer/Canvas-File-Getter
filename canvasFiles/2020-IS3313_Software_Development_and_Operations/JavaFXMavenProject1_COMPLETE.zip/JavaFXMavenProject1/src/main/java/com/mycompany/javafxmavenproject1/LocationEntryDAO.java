package com.mycompany.javafxmavenproject1;

import com.google.gson.Gson;
import java.io.IOException;
import java.util.logging.Level;
import java.util.logging.Logger;
import okhttp3.Call;
import okhttp3.OkHttpClient;
import okhttp3.Request;
import okhttp3.Response;

public class LocationEntryDAO {
    
    //Setup for remote object access
    private static final String BASE_URI = "https://location.simonwoodworth.com/gateway.php/location/";
    private static final OkHttpClient client = new OkHttpClient();
    
    //Fetch raw data from the server
    private static String fetchData(int id) {
                
        Request request = new Request.Builder()
            .url(BASE_URI + id)
            .build();
 
        Call call = client.newCall(request);
        try {
            Response response = call.execute();
            String body = response.body().string();
            return body;
        } catch (IOException ex) {
            Logger.getLogger(FXMLController.class.getName()).log(Level.SEVERE, null, ex);
            return "FAIL";
        }
    }
    
    //Retrieve a single LocationEntry object from the server
    public static LocationEntry fetchLocation(int id) {
        Gson gson = new Gson();
        String jsonString = fetchData(id);
        LocationEntry le = gson.fromJson(jsonString, LocationEntry.class);
        return le;
    }
    
}