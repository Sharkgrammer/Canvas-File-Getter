package com.mycompany.javafxmavenproject1;

public class LocationEntry {

    private long ID;
    private double Lat, Lng;
    private String Time;
    private String Note;
    
    public LocationEntry() {
    }

    public LocationEntry(double Lat, double Lng, String Time, String Note) {
        this.Lat = Lat;
        this.Lng = Lng;
        this.Time = Time;
        this.Note = Note;
    }

    public LocationEntry(long ID, double Lat, double Lng, String Time, String Note) {
        this.ID = ID;
        this.Lat = Lat;
        this.Lng = Lng;
        this.Time = Time;
        this.Note = Note;
    }

    public long getId() {
        return ID;
    }

    public void setId(long ID) {
        this.ID = ID;
    }

    public double getLat() {
        return Lat;
    }

    public void setLat(double Lat) {
        this.Lat = Lat;
    }

    public double getLng() {
        return Lng;
    }

    public void setLng(double Lng) {
        this.Lng = Lng;
    }

    public String getDatetime() {
        return Time;
    }

    public void setDatetime(String Time) {
        this.Time = Time;
    }

    public String getNote() {
        return Note;
    }

    public void setNote(String Note) {
        this.Note = Note;
    }

    @Override
    public String toString() {
        return "LocationEntry{" +
                "Lat=" + Lat +
                ", Lng=" + Lng +
                ", Time=" + Time +
                ", Note='" + Note + '\'' +
                '}';
    }
}
